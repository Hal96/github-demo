package com.udemy.service;

import java.util.List;

import com.udemy.model.Person;

public interface ExampleService 
{
	public abstract List<Person> getListPeople();

}
