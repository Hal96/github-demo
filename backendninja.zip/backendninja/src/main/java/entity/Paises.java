package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="pais")
public class Paises 
{
	@Id
	@GeneratedValue
	private long id;
	@Column(name = "name")
	private String name;
	@Column(name = "avname")
	private String avname;
	
	
	public String getName()
	{
		return name;
	}
	
	public String getAvname()
	{
		return avname;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setAvname(String avname) 
	{
		this.avname = avname;
	}
	
	public Paises(String name, String avname) 
	{
		super();
		this.name = name;
		this.avname = avname;
	}

}
